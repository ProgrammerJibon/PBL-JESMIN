<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=0.8">
    <link rel="stylesheet" href="/style.css?timestamp=<?php echo filemtime("css.php"); ?>">
    <script src="/script.js?timestamp=<?php echo filemtime("css.php"); ?>"></script>
</head>

<body>
    <main >
     